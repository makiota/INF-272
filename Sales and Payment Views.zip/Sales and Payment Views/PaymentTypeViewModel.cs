﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace u15150292WebMVC.Models
{
    public class PaymentTypeViewModel
    {
        public int PaymentTypeID { get; set; }
        public string PaymentTypeName { get; set; }
    }

    public class PaymentTypeListViewModel
    {
        public PaymentTypeListViewModel()
        {
            this.paymentList = new List<PaymentTypeViewModel>();
        }

        public List<PaymentTypeViewModel> paymentList { get; set; }
    }
}