﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using u15150292WebMVC.Models;
using u15150292WebMVC.Service;

namespace u15150292WebMVC.Controllers
{
    public class SalesController : Controller
    {
        #region constructor/destructor
        private readonly DefaultService _defaultService;
        private bool disposed;
        public SalesController()
        {
            _defaultService = new DefaultService();
        }
        ~SalesController()
        {
            Disposes(false);
        }
        public void Disposes()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Disposes(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                    _defaultService.Dispose();
                disposed = true;
            }
            base.Dispose(disposing);
        }
        #endregion

        public ActionResult PaymentType()
        {
            ViewBag.SuccessR = "";
            ViewBag.ErrorR = "";
            return View();
        }

        [HttpPost]
        public ActionResult PaymentType(PaymentTypeViewModel model)
        {
            var result = _defaultService.AddPaymentType(model.PaymentTypeName);
            if(result == "")
            {
                ViewBag.SuccessR = "Payment type has been added successfully";
                ViewBag.ErrorR = "";
            }
            else
            {
                ViewBag.ErrorR = result.ToString();
                ViewBag.SuccessR = "";
            }
            return View();
        }

        public ActionResult EditPaymentType()
        {
            ViewBag.SuccessR = "";
            ViewBag.ErrorR = "";
            var result = _defaultService.paymentTypeList().ToList();
            return View(result);
        }

        public ActionResult _EditPaymentType(int Id)
        {
            ViewBag.SuccessR = "";
            ViewBag.ErrorR = "";
            var model = new PaymentTypeViewModel();
            var result = _defaultService.paymentTypeView(Id);
            model.PaymentTypeID = result.PaymentTypeID;
            model.PaymentTypeName = result.PaymentTypeName;
            return View(model);
        }

        [HttpPost]
        public ActionResult _EditPaymentType(PaymentTypeViewModel model)
        {
            var result = _defaultService.editPaymentType(model);
            if (result == "")
            {
                ViewBag.SuccessR = "Payment type has been updated successfully";
                ViewBag.ErrorR = "";
            }
            else
            {
                ViewBag.ErrorR = result.ToString();
                ViewBag.SuccessR = "";
            }
            return View();
        }


    }
}